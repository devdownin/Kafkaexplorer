# Cyber Stream Design System

### 1. Overview & Creative North Star
**Creative North Star: "The Synthetic Pulse"**
Cyber Stream is a high-density, technical design system built for real-time data orchestration and infrastructure monitoring. It rejects the generic "SaaS Blue" aesthetic in favor of a high-contrast, terminal-inspired palette. The system prioritizes "Information Velocity"—the ability for a user to scan vast amounts of streaming data quickly through high-contrast accents, monospace highlights, and a rigid yet sophisticated layout. It feels like a futuristic command deck: precise, glowing, and deeply functional.

### 2. Colors
The palette is anchored by a deep teal-black neutral set (`#102222`) and a vibrant, luminescent primary Cyan (`#25f4f4`).
- **The "No-Line" Rule:** Traditional 1px solid borders are restricted. Structural separation is achieved through `surface-container` background shifts or 10% opacity primary-tinted outlines.
- **Surface Hierarchy & Nesting:** Use `surface_container_low` for the main canvas. Elevate cards using `primary/5` (5% opacity primary) to create a subtle "glow" effect rather than using heavy shadows.
- **The "Glass & Gradient" Rule:** Floating elements and headers should utilize a subtle backdrop-blur (12px+) with a semi-transparent primary-tinted background to maintain context.
- **Signature Textures:** Status indicators use "Pulse" animations (e.g., the Emerald-500 status dot) to signify live connection without cluttering the UI with text.

### 3. Typography
Cyber Stream uses **Inter** across all levels to ensure maximum legibility in high-density data views. 
**Actual Typography Scale:**
- **Display/KPIs:** `1.875rem` (30px) Bold. Used for critical metrics like message counts.
- **Headlines:** `1.25rem` (20px) Bold. Used for section titles (e.g., Topics Explorer).
- **Sub-headings:** `1.125rem` (18px) Semi-Bold.
- **Body Text:** `0.875rem` (14px) Medium. The standard for table content and navigation.
- **Labels/Meta:** `0.75rem` (12px) Bold/Uppercase. Used for table headers and category labels.
- **Micro-Labels:** `10px` Bold/Mono. Used for system IDs, timestamps, and secondary status badges.
The hierarchy conveys authority by using wide letter-spacing (`tracking-widest`) on uppercase labels, contrasting with tight, bold headlines.

### 4. Elevation & Depth
Depth is conveyed through **Tonal Layering** and luminosity rather than physical shadows.
- **The Layering Principle:** The sidebar and main header occupy the same base plane, while content cards are "etched" into the surface using `primary/5` fills.
- **Ambient Shadows:** The system avoids traditional box-shadows. Instead, it uses a "Glow" effect: `0px 0px 15px 0px rgba(37, 244, 244, 0.05)`.
- **The "Ghost Border" Fallback:** If an edge must be defined, use `border-primary/10` (10% opacity primary color).
- **Glassmorphism:** Navigation active states use a `primary/10` background to simulate a light-source highlight.

### 5. Components
- **Buttons:**
  - *Primary:* Solid Cyan background with Dark Teal text. Sharp corners (4px).
  - *Ghost/Action:* Transparent with a 10% primary border. Icons are `22px` for high visibility.
- **Data Tables:** High-density, no vertical lines. Headers are uppercase `12px` with `primary/70` text color. Rows use a subtle transition to `primary/5` on hover.
- **Status Badges:** Pill-shaped with 20% opacity backgrounds. Emerald (Healthy), Amber (DLT), Slate (Empty), and Red (Error).
- **KPI Cards:** Minimalist. Large `1.875rem` metrics with micro-trend indicators in the bottom-right corner.
- **Input Fields:** Chrome-less or subtle `primary/10` borders. Text is `14px`.

### 6. Do's and Don'ts
- **Do:** Use uppercase tracking for category headers to differentiate from interactive data.
- **Do:** Use the Primary Cyan sparingly for "active" or "live" states to maintain its visual impact.
- **Don't:** Use standard grey borders (`#ccc`). Everything must be tinted with the `seed_color` to maintain the "Cyber" atmosphere.
- **Don't:** Overuse shadows. Let the color shifts between `surface_container` tiers define the layout.
- **Do:** Ensure status colors (Red/Green) maintain high contrast against the dark teal backgrounds for accessibility.